<?php
if(session_id() == '') {
    session_start();
}
header('Content-Type: text/html; charset=UTF-8');
//ini_set("memory_limit", "128M");
//if (!ini_set('default_charset', 'utf-8')) {
//    echo "could not set default_charset to utf-8<br>";
//}
date_default_timezone_set('America/Sao_Paulo');
if($_SERVER['REMOTE_ADDR']=='189.90.65.203'
        or $_SERVER['REMOTE_ADDR']=='189.90.70.566'
        or @$_SERVER['HTTP_X_REAL_IP']=='201.94.202.511'
        or @$_SERVER['HTTP_X_REAL_IP']=='179.253.235.159'
//        or @$_SERVER['REMOTE_ADDR']=='200.203.142.25'
        or $_SERVER['HTTP_HOST']=='eventos.test'
    ){
    error_reporting(E_ALL ^ E_NOTICE);
    ini_set("display_errors", "On");
    $debug = false;
}else{
//if($_SESSION['_login']=='zakacc@gmail.com3'){
//    error_reporting(E_ALL ^ E_NOTICE);
//    ini_set("display_errors", "On");
//}else{
    ini_set("display_errors", "Off");
    $debug = false;
}

$MSG = false;
foreach ($_GET as $keyG => $valG) {
    $valG = (!is_array($valG)? addslashes($valG) : "");
    $keyG = (!is_array($keyG)? addslashes($keyG) : "");
    $fwsGet_[$keyG] = $valG;
}
//}
foreach ($_POST as $key => $val) {
//    if (mb_detect_encoding($val . 'x', 'UTF-8, ISO-8859-1') == 'UTF-8') {
//        $val = utf8_decode(addslashes($val));
//    } else {
        $val = (!is_array($val)? addslashes($val) : "");
//    }
    /**/
    if(strpos($key, '_')){
        $key = strtolower($key);
    }
    $fws_[$key] = $val;
    if ($fws_[$key] == 'undefined') {
        $fws_[$key] = "";
    }
    if ($debug) {
        echo "post -> fws_['" . $key . "'] => " . $val . " - " . $fws_[$key] . "<br>";
    }
    //Capturando array
    if (is_array($_POST[$key])) {
        $fws_[$key] = $_POST[$key];
        for ($ii = 0; $ii < count($_POST[$key]); $ii++) {
            $valArray = $_POST[$key][$ii];
            if (mb_detect_encoding($valArray . 'x', 'UTF-8, ISO-8859-1') == 'UTF-8') {
                $valArray = utf8_decode(addslashes($valArray));
            } else {
                $valArray = addslashes($valArray);
            }
            $fws_[$key][$ii] = $valArray;
            if ($debug) {
                echo "Array post -> fws_['" . $key . "']['" . $ii . "'] => " . $valArray . " - " . $fws_[$key][$ii] . "<br>";
            }
        }
    }
}
   
If (@$fws_['msg'] == "") {
    $fws_['msg'] = $_SESSION['MSG'];
//    if (!mb_detect_encoding($fws_['msg'] . 'x', 'UTF-8, ISO-8859-1') == 'UTF-8') {
//        $fws_['msg'] = utf8_decode(addslashes($fws_['msg']));
//    } else {
        $fws_['msg'] = addslashes($fws_['msg']);
//    }
}

require_once(dirname(__FILE__)."/functions/functions.php");
if($fws_['cpf']){
    $fws_['cpf'] = formatCpfInsert($fws_['cpf']);
}
switch ($fwsGet_['rota']) {
    case '1':
        define('COD_EVENTO',  '1');
        define('WB_GRUPO', 'sbmp');
        define('WB_PROJETO', '9congresso');
        break;
    case '4congresso':
        define('COD_EVENTO',  '2');
        define('WB_GRUPO', 'inesco');
        define('WB_PROJETO', '4congresso');
        break;
    case '5mostrasparanaensesaude':
        define('COD_EVENTO',  '3');
        define('WB_GRUPO', 'inesco');
        define('WB_PROJETO', '5mostrasparanaensesaude');
        break;
    case '5congresso':
        define('COD_EVENTO',  '4');
        define('WB_GRUPO', 'inesco');
        define('WB_PROJETO', '5congresso');
        break;
    case 'cresspr/plenaria':
        define('COD_EVENTO',  '5');
        define('WB_GRUPO', 'cresspr');
        define('WB_PROJETO', 'cresspr/plenaria');
        break;
    case '7mostraparanaensesaude':
        define('COD_EVENTO',  '6');
        define('WB_GRUPO', 'inesco');
        define('WB_PROJETO', '7mostraparanaensesaude');
        break;
    case '6congresso':
        define('COD_EVENTO',  '7');
        define('WB_GRUPO', 'inesco');
        define('WB_PROJETO', '6congresso');
        break;
    case 'pacbase':
        define('COD_EVENTO',  '8');
        define('WB_GRUPO', 'pstc');
        define('WB_PROJETO', 'pacpase');
        break;
    case 'ingressos':
        define('COD_EVENTO',  '9');
        define('WB_GRUPO', 'aremac');
        define('WB_PROJETO', 'ingressos');
        break;
    case '10':
    case 'cursos':
        define('COD_EVENTO',  '10');
        define('WB_GRUPO', 'hutec');
        define('WB_PROJETO', 'cursos');
        break;
    case '15':
    case 'ccip':
        define('COD_EVENTO',  '15');
        define('WB_GRUPO', 'hutec');
        define('WB_PROJETO', 'ccip');
        break;
    case '14':
    case 'hu-depe':
        define('COD_EVENTO',  '14');
        define('WB_GRUPO', 'hutec');
        define('WB_PROJETO', 'hu-depe');
        break;
    case '13':
    case 'hu':
        define('COD_EVENTO',  '13');
        define('WB_GRUPO', 'hutec');
        define('WB_PROJETO', 'hu');
        break;
    case '12':
    case 'acls':
        define('COD_EVENTO',  '12');
        define('WB_GRUPO', 'hutec');
        define('WB_PROJETO', 'acls');
        break;
    case 'comuel':
    case '11':
        define('COD_EVENTO',  '11');
        define('WB_GRUPO', 'hutec');
        define('WB_PROJETO', '11');
        break;
    case 'admin':
        if($_SESSION['_administrativo']==1 and ($fwsGet_['cod_evento']!='' OR $fws_['cod_evento']!='')){
            if($fwsGet_['cod_evento']!=''){
                define('COD_EVENTO',  $fwsGet_['cod_evento']);
            }else{
                define('COD_EVENTO',  $fws_['cod_evento']);
            }
            define('WB_PROJETO', COD_EVENTO);
        }else{
            define('COD_EVENTO',  '9999');
            define('WB_PROJETO', 'admin');
        }
        define('WB_GRUPO', 'hutec');
        break;
    default:
//        if($fwsGet_['rota']>=16){
            if(file_exists(dirname(__FILE__).'/config-'.$fwsGet_['rota'].'.php')){
                $arqConfig = true;
                define('COD_EVENTO', $fwsGet_['rota']);
                define('WB_GRUPO', 'hutec');
                define('WB_PROJETO', $fwsGet_['rota']);
            }else{
                $arqConfig = false;
            }
//        }else{
//            $arqConfig = false;
//        }
        break;
}

$COD_EVENTO = COD_EVENTO;
$cod_evento = COD_EVENTO;

$PROTOCOLO = "https";
//if($_SERVER["HTTPS"]){
//    $PROTOCOLO = "https";
//}

switch ($_SERVER["SERVER_NAME"]) {
    case "www.opctec.net.br":
    case "opctec.net.br":
    case "www.opctec.com.br":
    case "opctec.com.br":
        define('WB_PERSPECTIVA', 'local');
        define('WB_ROOT', $_SERVER['DOCUMENT_ROOT'] ."/");
        //definindo WB_PROJETO
        $dir = dirname(__FILE__);
        //para linux a barra do explode para separar os diretório é ao contrario
        $arrayDir = explode('/', $dir);
//        define('WB_PROJETO', $arrayDir[count($arrayDir)-3]);
        define('WB_PATH', '/'.WB_GRUPO.'/'.WB_PROJETO.'/inscricoes');
        //define('GOOGLE_KEY', '6LegLLkUAAAAAPmMa9BQnN6VSOKQ4xAwADvbHZM1');
        define('GOOGLE_KEY', '6Lc2oAIbAAAAABgnuDtnwj9twSFm1IXHKzN6Xi-K');
        define('URL_BOLETO', 'https://opctec.net.br');
        define('WB_URL', 'https://opctec.net.br');

//        if(WB_PROJETO==10){
//            include 'config-cursos.php';
//        }else{
//            include 'config-'.WB_PROJETO.'.php';
//        }
        break;
    case "eventos.test":
        $PROTOCOLO = "https";
        define('URL_BOLETO', 'https://eventos.test');
        define('WB_URL', 'https://eventos.test');
//        define('GOOGLE_KEY', '6Lc2oAIbAAAAABgnuDtnwj9twSFm1IXHKzN6Xi-K');
        define('WB_PERSPECTIVA', 'local');
        define('WB_ROOT', $_SERVER['DOCUMENT_ROOT'].'/');
        define('WB_PATH', '/'.WB_GRUPO.'/'.WB_PROJETO.'/inscricoes');

//        include 'config-cursoslocal.php';
//        include 'config-'.WB_PROJETO.'.php';
        break;
    default :
        define('WB_PERSPECTIVA', 'prod');
        define('WB_ROOT', $_SERVER['DOCUMENT_ROOT']);
        //definindo WB_PROJETO
        $dir = dirname(__FILE__);
        $arrayDir = explode('\\', $dir);
//        define('WB_PROJETO', $arrayDir[count($arrayDir)-3]);
        define('WB_PATH', '/'.WB_GRUPO.'/'.WB_PROJETO.'/inscricoes');
        define('WB_URL', 'http://www.opctec.net.br');
        define('URL_BOLETO', 'https://opctec.net.br');
//        include 'config-'.WB_PROJETO.'.php';
        break;
}
if($_SERVER['REMOTE_ADDR']=='189.90.70.56' or $_SERVER['REMOTE_ADDR']=='189.90.70.203' or $_SERVER['REMOTE_ADDR']=='189.35.135.201' or $_SERVER['REMOTE_ADDR']=='177.100.49.198'){
//    $OP_EDICAO_DADOS_PESSOAIS = true;
//    $OP_PROCESSO_INSCRICAO    = true;
//    $OP_SUBMISSAO_TRABALHO    = true;
//    $OP_TRAMITACAO_TRABALHO   = true;
//    $OP_EMISSAO_BOLETO        = false;
//    $OP_GERAR_BOLETO          = false;
//    $OP_EMISSAO_CERTIFICADOS  = false;
//    $OP_EMISSAO_RECIBOS       = false;
//    $OP_EMISSAO_CARTA_ACEITE  = false;
//    $OP_EMISSAO_COMPROVANTE_INSCRICAO  = false;
//    $OP_EMISSAO_BOLETO_EXTRA = false;
}
define('WB_URL_AVALIAR_EVENTO',WB_URL.'/'.WB_GRUPO.'/'.WB_PROJETO.'/avaliar_evento');
define('WB_URL_CERTIFICADO',WB_URL.'/'.WB_GRUPO.'/'.WB_PROJETO.'/certificados');
define('WB_URL_VALIDAR_CERTIFICADO',WB_URL.'/'.WB_GRUPO.'/'.WB_PROJETO.'/certificados/validar');
define('WB_URL_CARTA_ACEITE',WB_URL.'/'.WB_GRUPO.'/'.WB_PROJETO.'/carta_aceite');
define('WB_URL_COMPROVANTE_INSCRICAO',WB_URL.'/'.WB_GRUPO.'/'.WB_PROJETO.'/comprovante_inscricao');

define('IP',$_SERVER['REMOTE_ADDR']);
define('DOMINIO_URL',WB_URL);

define('WB_PATH_COD_EVENTO',str_pad(COD_EVENTO, '3', "0", STR_PAD_LEFT));
define('WB_PATH_LOG', WB_ROOT . '../log/eventos/'.WB_PATH_COD_EVENTO . '/');
define('WB_PATH_LOG_CACHE', WB_ROOT . '../log/cache/');
define('WB_PATH_LOG_TRABALHO', WB_ROOT . '../log/eventos/'.WB_PATH_COD_EVENTO.'/trabalhos/');
define('WB_PATH_LOG_APRESENTACAO', WB_ROOT . '../log/eventos/'.WB_PATH_COD_EVENTO.'/apresentacao/');
define('WB_PATH_LOG_VIDEO', WB_ROOT . '../log/eventos/'.WB_PATH_COD_EVENTO.'/video/');
define('WB_PATH_LOG_REMESSA', WB_ROOT . '../log/eventos/'.WB_PATH_COD_EVENTO.'/remessa/');
define('WB_PATH_LOG_EXTBOLETO', WB_ROOT . '../log/eventos/'.WB_PATH_COD_EVENTO.'/extrato_boletos/');
define('WB_PATH_LOG_RETBOLETO', WB_ROOT . '../log/eventos/'.WB_PATH_COD_EVENTO.'/retorno/');
define('WB_PATH_LOG_BOLETO', WB_ROOT . '../log/eventos/'.WB_PATH_COD_EVENTO.'/boletos/');
define('WB_PATH_LOG_CERTIFICADOS', WB_ROOT . '../log/eventos/'.WB_PATH_COD_EVENTO.'/certificados/');
define('WB_PATH_LOG_RECIBOS', WB_ROOT . '../log/eventos/'.WB_PATH_COD_EVENTO.'/recibos/');
define('WB_PATH_LOG_CARTAS_ACEITE', WB_ROOT . '../log/eventos/'.WB_PATH_COD_EVENTO.'/cartas_aceite/');
define('WB_PATH_LOG_COMPROVANTES_INSCRICAO', WB_ROOT . '../log/eventos/'.WB_PATH_COD_EVENTO.'/comprovantes_inscricao/');
define('WB_PATH_LOG_DECLARACAO_PRESENCA', WB_ROOT . '../log/eventos/'.WB_PATH_COD_EVENTO.'/declaracao_presenca/');
define('WB_PATH_LOG_LISTA_CHAMADA', WB_ROOT . '../log/eventos/'.WB_PATH_COD_EVENTO.'/lista_chamada/');
define('WB_PATH_LOG_APP', WB_ROOT . '../log/eventos/'.WB_PATH_COD_EVENTO.'/app/');
define('WB_PATH_LIB', WB_ROOT . WB_PATH_COD_EVENTO.'/inscricoes/lib/');

define('SISTEM_PATH', dirname(__FILE__));
define('SITE', FWA_URL_Prefixo()); // local onde está a raiz do site
define('SITE_PATH', dirname(__FILE__)); // local onde está a raiz do site

#define('TEMPLATE_DIR', SITE . '/portal/templates/'.DEFAULT_TEMPLATE); // local do template usado no site, a partir de SITE
#define('TEMPLATE_PATH', SITE_PATH . '/portal/templates/'.DEFAULT_TEMPLATE); // local do template usado no site, a partir de SITE

define('WB_URL_ACTION', $PROTOCOLO.'://'.FWA_Dominio() . SITE .'/index-action.php');
define('WB_URL_CLEAN', $PROTOCOLO.'://'.FWA_Dominio() . SITE .'/index-clean.php');
define('WB_URL_MODAL', $PROTOCOLO.'://'.FWA_Dominio() . SITE .'/index-modal.php');
define('WB_URL_SITE', $PROTOCOLO.'://'.FWA_Dominio() . SITE);
define('WB_URL_COMMAND', WB_URL_ACTION.'?content=controller/CommandAC.php');

define('WB_URL_IMG', $PROTOCOLO.'://'.FWA_Dominio() . SITE .'/resources/image');
define('WB_URL_IMG_BOLETO', $PROTOCOLO.'://'.FWA_Dominio() . SITE .'/lib/boleto/imagens/');
@define('WB_URL', $PROTOCOLO.'://'.FWA_Dominio() . SITE );
define('WB_URL_VIEW', $PROTOCOLO.'://'.FWA_Dominio() . SITE .'/index.php');

define('WB_PATH_SECURITY', "view/financeiro,view/admin");

if(!file_exists(WB_PATH_LOG)){ mkdir(WB_PATH_LOG); }
/*
 * Definindo diretório para busca de classes
 * Evitando a necessidade de inserir includes ou requires
 * Afim de evitar sobrecarregar o servidor com arquivos desnecessários
 */
$path = WB_ROOT . 'lib/cursos/inscricoes' . '/controller';
$path .= PATH_SEPARATOR . WB_ROOT . 'lib/cursos/inscricoes' . '/domain';
$path .= PATH_SEPARATOR . WB_ROOT . 'lib/cursos/inscricoes' . '/domain/util';
$path .= PATH_SEPARATOR . WB_ROOT . 'lib/cursos/inscricoes' . '/domain/business';
$path .= PATH_SEPARATOR . WB_ROOT . 'lib/cursos/inscricoes' . '/domain/entity';
$path .= PATH_SEPARATOR . WB_ROOT . 'lib/cursos/inscricoes' . '/domain/entity/dao';
$path .= PATH_SEPARATOR . WB_ROOT . 'lib/cursos/inscricoes' . '/domain/entity/vo';
$path .= PATH_SEPARATOR . WB_ROOT . 'lib/cursos/inscricoes' . '/lib/PDFMerger';

set_include_path(get_include_path() . PATH_SEPARATOR . $path);

//echo get_include_path();
//if (!function_exists('__autoload')) {
//    function __autoload($class_name) {
        spl_autoload_register(function($class_name) {
        $fileClass = $class_name . ".php";
    //    if(file_exists($fileClass)) {
            require_once $fileClass;
    //    }else{
    //        echo "Arquivo da classe não encontrado:<br>".$fileClass.".<br>";
    //    }
    });
//}

include 'config-padrao.php';

