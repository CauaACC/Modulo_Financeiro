<?php
$objEv = new Evento();
$objEv->setCodEvento(COD_EVENTO);
$objEv->getEventoById();
$objEvConf = $objEv->getEventoConfiguracao();
//dd($objEv);
//exit;

define('TITLE_APP', $objEv->getTituloEvento());
define('DESC_EVENTO', $objEv->getTituloEvento());
define('DESC_EVENTO_RODAPE',  $objEv->getDescRodape());
define('NOME_EVENTO', $objEv->getTituloEvento());
define('ABREV_EVENTO',$objEv->getAbrevEvento());
define('ANO_EVENTO',  $objEv->getAnoEvento());

define('FONE_CONTATO',$objEv->getFoneContato());
define('FONE_CONTATO_WHATS',$objEv->getFoneContatoWhats());
define('LINK_CONTATO_WHATS','https://api.whatsapp.com/send?phone='.$objEv->getFoneContatoWhats());

define('ABREV_EVENTO_EMAIL',$objEv->getAbrevEventoEmail());
define('EMAIL_CONTATO',$objEv->getEmailContato());
define('EMAIL_REPLAY_TO',$objEv->getEmailReplayTo());
define('EMAIL_BCC',$objEv->getEmailBcc());
define('EMAIL_CONTATO_ATT', $objEv->getEmailContatoAtt());
define('EMAIL_CONTATO_LINK', $objEv->getEmailContatoLink());
define('EMAIL_CONTATO_LINK_AVALIACAO', $objEv->getEmailContatoLinkAvaliacao());
define('EMAIL_CONTATO_LINK_ADMIN', $objEv->getEmailContatoLinkAdmin());
define('EMAIL_CONTATO_LINK_LOGIN', $objEv->getEmailContatoLinkLogin());
define('LINK_CONTATO', $objEv->getLinkContato());

define('PRESIDENTE',   $objEv->getPresidente());
define('PRESIDENTE_TITULO', $objEv->getPresidenteTitulo());
define('PERIODO', $objEv->getPeriodo());
define('CIDADE_UF', $objEv->getCidadeUf());

define('URL_HOME_MENU', $objEv->getUrlHomeMenu());
define('URL_LOGO', $objEv->getUrlLogo());
define('URL_BOLETO', $objEv->getUrlBoleto());
define('URL_FACE', $objEv->getUrlFace());
define('URL_YOUTUBE', $objEv->getUrlYoutube());
define('URL_INSTAGRAM', $objEv->getUrlInstagram());
define('URL_TWITTER', $objEv->getUrlTwitter());
define('URL_LINKEDIN', $objEv->getUrlLinkedin());
define('URL_OFICIAL', $objEv->getUrlOficial());
//define('LOGO_RODAPE', 'logo-rodape-'.COD_EVENTO.'.png');
define('LOGO_RODAPE', $objEv->getLogoRodape());

$fws['headers']     = "Bcc: zakacc@gmail.com\r\n".
$fws['emailEvento'] = "zakacc@gmail.com";

$headers = "MIME-Version: 1.1\r\n";
$headers .= "Content-type: text/plain; charset=UTF-8\r\n";
$headers .= "From: ".ABREV_EVENTO_EMAIL." <eventos@opctec.com.br>\r\n"; // remetente
$headers .= "Bcc: eventos@opctec.com.br\r\n"; // remetente
//$headers .= "Bcc: zakacc@gmail.com\r\n"; // remetente
if(EMAIL_REPLAY_TO!=''){
    $headers .= "Replay-To: ".EMAIL_REPLAY_TO."\r\n"; // remetente
    $headers .= "Return-Path: ".EMAIL_REPLAY_TO."\r\n"; // return-path
}

define('HEADER_EMAIL', $headers);
define('FWA_REFRESH_TIME' , '2');

if($objEvConf->getSimularData()==true){
    $FWS_Data_Hoje   = $objEvConf->getDataSimular();
    $FWS_Data_HojeHM = $objEvConf->getDataSimular();
}else{
    $FWS_Data_Hoje   = Date('Ymd');
    $FWS_Data_HojeHM = Date('YmdHi');
}
$FWS_Data_Inscricao_Inicio        = $objEvConf->getDataInscricaoInicio();
$FWS_Data_Ini_Submissao_Trabalho  = $objEvConf->getDataIniSubimissaoTrabalho();

$FWS_Data_Liberar_Boleto = $objEvConf->getDataLiberarBoleto();

$FWS_Data_Liberar_Certificado   = $objEvConf->getDataLiberarCertificado();
$FWS_Data_Inscricao_Fim         = $objEvConf->getDataInscricaoFim();
$FWS_Data_Edicao_Dados_Pessoais = $FWS_Data_Inscricao_Fim+7;
$FWS_Data_Trabalho_Tramitacao_Fim = $objEvConf->getDataTrabalhoTramitacaoFim();
$FWS_Data_Max_Submissao_Trabalho  = $objEvConf->getDataMaxSubmissaoTrabalho();
$FWS_Data_Divulgacao_Trabalho_Aprovado  = $objEvConf->getDataDivulgacaoTrabalhoAprovado();
$FWS_Data_Divulgacao_Trabalho_Reprovado = $objEvConf->getDataDivulgacaoTrabalhoReprovado();
define('TRABALHO_ANEXA_RESUMO', $objEvConf->getTrabalhoAnexaoResumo());
define('TRABALHO_ANEXA_RESUMO_FORMULARIO', $objEvConf->getTrabalhoAnexaoResumoFormulario());
define('DESC_ATIVIDADE', $objEvConf->getDescAtividade());

$FWS_Numero_Maximo_Trabalhos = $objEvConf->getNumeroMaximoTrabalhos();
$FWS_Numero_Maximo_Trabalhos_Atrelado_ao_Perfil = $objEvConf->getNumeroMaximoTrabalhosAtretadoAoPerfil();

$FWS_Data_Max_Submissao_Trabalho_Mensagem = $objEvConf->getDataMaxSubmissaoTrabalhoMensagem();
$msg_tela_login_envio_trabalho = $objEvConf->getMsgTelaLoginEnvioTrabalho();
$FWS_Liberar_Ja_Estou_Inscrito = $objEvConf->getLiberarJaEstouInscrito();
$msg_tela_previsao_inicio      = "Inicio das inscrições previsto para ".formatDateView($FWS_Data_Inscricao_Inicio).".";
//$msg_tela_previsao_inicio      = 1;

$FWS_Dias_Prazo_Pagamento = 5;
$OP_PROCESSO_INSCRICAO_SUSPENSO = $objEvConf->getOpProcessoInscricaoSupenso();

/**Evento Online */
$OP_EVENTO_ONLINE_LIBERADO = $objEvConf->getOpEventoOnlineLiberado();
$OP_EVENTO_ONLINE_YOUTUBE_LIBERADO = $objEvConf->getOpEventoOnlineYoutubeLiberado();
$OP_EVENTO_ONLINE_MOSTRA_LIBERADO = $objEvConf->getOpEventoOlineMostraLiberado();
$OP_EVENTO_ONLINE_LINK_MINICURSO_LIBERADO = $objEvConf->getOpEventoOnlineLinkMinicursoLiberdo();
$OP_EVENTO_AVISOS = $objEvConf->getOpEventoAvisos();

$OP_PROCESSO_INSCRICAO = $objEvConf->getOpProcessoInscricao();
$OP_SUBMISSAO_TRABALHO = $objEvConf->getOpSubmissaoTrabalho();
$OP_SUBMISSAO_TRABALHO_AGUARDANDO = $objEvConf->getOpSubimissaoTrabalhoAguardando();
$OP_SUBMISSAO_TRABALHO_ENCERRADA = $objEvConf->getOpSubimissaoTrabalhoEncerrada();
$OP_TRAMITACAO_TRABALHO = $objEvConf->getOpTramitacaoTrabalho();
$OP_AVALIACAO_ENVIAR_AO_SALVAR = $objEvConf->getOpAvaliacaoEnviarAoSalvar();

$SIS_ADM_AVALIACAO_TRABALHOS = $objEvConf->getSisAdmAvaliacaoTrabalho();
$SIS_AVALIACAO_TRABALHOS_PREMIADOS = $objEvConf->getSisAvaliacaoTrabalhosPremiados();
$SIS_ADM_AVALIACAO_TRABALHOS_DEFINIR_PREMIADOS = $objEvConf->getSisAdmAvaliacaoTrabalhosDefinirPremiados();

$OP_DIVULGAR_TRABALHO_REPROVADO = $objEvConf->getOpDivultarTrabalhoReprovado();
$OP_DIVULGAR_TRABALHO_APROVADO = $objEvConf->getOpDivulgarTrabalhoAprovado();
$OP_DIVULGAR_ENSALAMENTO = $objEvConf->getOpDivulgarEnsalamento();

$OP_ANEXAR_VIDEO = $objEvConf->getOpAnexarVideo();
$OP_ANEXAR_APRESENTACAO_VIDEO_ENCERRADO = $objEvConf->getOpAnexarApresentacaoVideoEncerrado();
$OP_PERMITIR_ANEXAR_VIDEO = $objEvConf->getOpPermitirAnexarVideo();
$OP_ANEXAR_APRESENTACAO           = $objEvConf->getOpAnexarApresentacao();
$OP_PERMITIR_ANEXAR_APRESENTACAO  = $objEvConf->getOpPermitirAnexarApresentacao();
$OP_ANEXAR_APRESENTACAO_ENCERRADO = $objEvConf->getOpAnexarApresentacaoEncerrado();


$OP_EDICAO_DADOS_PESSOAIS = $objEvConf->getOpEdicaDadosPessoais();
$OP_EMISSAO_CERTIFICADOS  = $objEvConf->getOpEmissaoCertificados();
$OP_EMISSAO_RECIBOS       = $objEvConf->getOpEmissaoRecibos();
$OP_EMISSAO_CARTA_ACEITE  = $objEvConf->getOpEmissaoCartaAceite();
$OP_EMISSAO_COMPROVANTE_INSCRICAO = $objEvConf->getOpEmissaoComprovanteInscricao();
$OP_EMISSAO_DECLARACAO_PRESENCA  =$objEvConf->getOpEmissaoDeclaracaoPresenca();

$OP_BLOQUEAR_ALTERACAO_SE_BOLETO_GERADO = false;
$OP_GERAR_BOLETO = $objEvConf->getOpGerarBoleto();
$OP_INCRICAO_GRATUITA = $objEvConf->getOpInscricaoGratuita();
$OP_EMISSAO_BOLETO = $objEvConf->getOpEmissaoBoleto();
$OP_EMISSAO_BOLETO_EM_MANUTENCAO = $objEvConf->getOpEmissaoBoletoManutencao();

$OP_EMISSAO_BOLETO_EXTRA = false;
$OP_MENSAGEM_BTN_BOLETO  = false;
$OP_SELECIONAR_ALMOCO    = false;
/**/
$OP_PERMITIR_ALTERAR_EVENTO_PARALELO   = false;
$OP_PERMITIR_ADICIONAR_EVENTO_PARALELO = false;
$fws['op_selecionar_evento_paralelo_botao_personalizado'] = true;
$OP_PERMITIR_MAX_EVENTO_PARALELO        = 2;
$fws_['op_selecionar_evento_paralelo'] = $objEvConf->getOpSelecionarEventoParalelo();
$fws_['op_selecionar_oficina']         = $objEvConf->getOpSelecionarOficina();
$fws_['op_selecionar_oficina_apos_inscricao'] = $objEvConf->getOpSelecionarOficinaAposInscricao();
$fws_['op_excluir_oficina_apos_inscricao']    = $objEvConf->getOpExcluirOficinaAposInscricao();
$OP_PERMITIR_ALTERAR_OFICINA = $objEvConf->getOpPermitirAlterarOficina();

$fws_['op_dados_pessoais_profissao']   = $objEvConf->getOpDadosPessoaisProfissao();
$fws_['op_dados_pessoais_complemento'] = $objEvConf->getOpDadosPessoaisComplemento();
$OP_NOME_CRACHA = $objEvConf->getOpNomeCracha();
$fws_['op_dados_pessoais_tipo_instituicao'] = $objEvConf->getOpDadosPessoaisTipoInstituicao();
$fws_['op_dados_pessoais_data_nascimento']  = $objEvConf->getOpDadosPessoaisDataNascimento();
$fws_['op_dados_pessoais_recibo'] = $objEvConf->getOpDadosPessoaisRecibo();

define('MAX_OFICINAS', '3');
/*Valores*/
$OP_VALOR_OFICINA   = 0;
$OP_VALOR_ALMOCO    = 0;
$OP_VALOR_INSCRICAO = 0;
$OP_PERMITIR_TESTAR_PERMISSAO_POR_DATA_INSCRICAO = false;
  
if('202207090730'<=$FWS_Data_HojeHM and $FWS_Data_HojeHM<='202207112359'){
    $OP_EVENTO_ONLINE_YOUTUBE_LIBERADO = true;
}
if($_SERVER['REMOTE_ADDR']=='179.154.183.222' or ('202207090730'<=$FWS_Data_HojeHM and $FWS_Data_HojeHM<='202207112359')){
    $OP_EVENTO_ONLINE_MOSTRA_LIBERADO = true;
}
if ($_SERVER['REMOTE_ADDR']=='179.154.183.222' or ('202207090730'<=$FWS_Data_HojeHM and $FWS_Data_HojeHM<='202207112359')){
    $OP_EVENTO_ONLINE_LINK_MINICURSO_LIBERADO = true;
}
if($FWS_Data_Inscricao_Inicio <= $FWS_Data_Hoje and $FWS_Data_Hoje <= $FWS_Data_Inscricao_Fim){
    $OP_PROCESSO_INSCRICAO = true;
}
if($FWS_Data_Ini_Submissao_Trabalho <= $FWS_Data_Hoje and $FWS_Data_Hoje <= $FWS_Data_Max_Submissao_Trabalho ){
    $OP_SUBMISSAO_TRABALHO = true;
}
if($FWS_Data_Hoje < $FWS_Data_Ini_Submissao_Trabalho ){
    $OP_SUBMISSAO_TRABALHO_AGUARDANDO = true;
}
if($FWS_Data_Max_Submissao_Trabalho <= $FWS_Data_Hoje){
    $OP_SUBMISSAO_TRABALHO_ENCERRADA = true;
}
//if ($_SESSION['cod_inscrito'] == '5016') {
//    $OP_SUBMISSAO_TRABALHO = true;
//}
if($FWS_Data_Inscricao_Inicio <= $FWS_Data_Hoje and $FWS_Data_Hoje <= $FWS_Data_Trabalho_Tramitacao_Fim ){
    $OP_TRAMITACAO_TRABALHO = true;
}
if($FWS_Data_Divulgacao_Trabalho_Reprovado <= $FWS_Data_Hoje){
    $OP_DIVULGAR_TRABALHO_REPROVADO = true;
}
if($FWS_Data_Divulgacao_Trabalho_Aprovado <= $FWS_Data_Hoje){
    $OP_DIVULGAR_TRABALHO_APROVADO = true;
}
if($_SERVER['REMOTE_ADDR']=='189.90.70.56' or $_SERVER['REMOTE_ADDR']=='200.250.28.242'){
    $OP_ANEXAR_APRESENTACAO_VIDEO_ENCERRADO = false;
    $OP_PERMITIR_ANEXAR_VIDEO = true;
}
if($_SERVER['REMOTE_ADDR']=='189.90.70.56' or $_SERVER['REMOTE_ADDR']=='200.250.28.242'){
    $OP_ANEXAR_APRESENTACAO_ENCERRADO = false;
    $OP_PERMITIR_ANEXAR_APRESENTACAO = true;
}
if($FWS_Data_Liberar_Boleto <= $FWS_Data_Hoje and $FWS_Data_Hoje <= $FWS_Data_Inscricao_Fim){
    $OP_GERAR_BOLETO = true;
}
if($FWS_Data_Hoje <= $FWS_Data_Edicao_Dados_Pessoais){
    $OP_EDICAO_DADOS_PESSOAIS = true;
}
if($FWS_Data_Liberar_Certificado <= $FWS_Data_HojeHM){
    $OP_EMISSAO_CERTIFICADOS = true;
}
if($FWS_Data_Inscricao_Inicio <= $FWS_Data_Hoje){
    $OP_EMISSAO_RECIBOS = true;
}
if($FWS_Data_Inscricao_Inicio <= $FWS_Data_Hoje){
    $OP_EMISSAO_CARTA_ACEITE = true;
}
//if($FWS_Data_Inscricao_Inicio <= $FWS_Data_Hoje){
//    $OP_EMISSAO_COMPROVANTE_INSCRICAO = true;
//}
//if($_SERVER['REMOTE_ADDR']=='10.10.105.3'){
//    $OP_EMISSAO_BOLETO = false;
//    $OP_EMISSAO_BOLETO_EM_MANUTENCAO = true;
//}
    
////if($arqConfig==false){
//    header('Location: https://'.$_SERVER['SERVER_NAME']);
//    exit;
//}

$ipLiberado = false;

if($_SERVER['REMOTE_ADDR']=='189.90.70.56' or $_SERVER['REMOTE_ADDR']=='177.100.49.198'){
    $ipLiberado = true;
    define('IP_LIBERADO',true);
}

$content = addslashes($_GET['content']);
If ($content == "") {
    $content = addslashes($_POST['content']);
    If ($content == "") {
        $content = "default.php";
    }
}
