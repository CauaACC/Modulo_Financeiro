<?php
session_start();
header('Content-Type: text/html; charset=UTF-8');
//ini_set("memory_limit", "128M");
//if (!ini_set('default_charset', 'utf-8')) {
//    echo "could not set default_charset to utf-8<br>";
//}
date_default_timezone_set('America/Sao_Paulo');
if($_SERVER['REMOTE_ADDR']=='189.90.65.203'
        or $_SERVER['REMOTE_ADDR']=='189.90.70.566'
        or @$_SERVER['HTTP_X_REAL_IP']=='201.94.202.511'
        or @$_SERVER['HTTP_X_REAL_IP']=='179.253.235.159'
        or $_SERVER['HTTP_HOST']=='eventos.test-fora'){
    error_reporting(E_ALL ^ E_NOTICE);
    ini_set("display_errors", "On");
    $fwsDebug = true;
}else{
    ini_set("display_errors", "Off");
    $fwsDebug = false;
}

$MSG = false;
foreach ($_GET as $keyG => $valG) {
    $valG = (!is_array($valG)? addslashes($valG) : "");
    $keyG = (!is_array($keyG)? addslashes($keyG) : "");
    $fwsGet_[$keyG] = $valG;
}
//}
foreach ($_POST as $key => $val) {
//    if (mb_detect_encoding($val . 'x', 'UTF-8, ISO-8859-1') == 'UTF-8') {
//        $val = utf8_decode(addslashes($val));
//    } else {
        $val = (!is_array($val)? addslashes($val) : "");
//    }
    /**/
    if(strpos($key, '_')){
        $key = strtolower($key);
    }
    $fws_[$key] = $val;
    if ($fws_[$key] == 'undefined') {
        $fws_[$key] = "";
    }
    if ($fwsDebug) {
        echo "post -> fws_['" . $key . "'] => " . $val . " - " . $fws_[$key] . "<br>";
    }
    //Capturando array
    if (is_array($_POST[$key])) {
        $fws_[$key] = $_POST[$key];
        for ($ii = 0; $ii < count($_POST[$key]); $ii++) {
            $valArray = $_POST[$key][$ii];
            if (mb_detect_encoding($valArray . 'x', 'UTF-8, ISO-8859-1') == 'UTF-8') {
                $valArray = utf8_decode(addslashes($valArray));
            } else {
                $valArray = addslashes($valArray);
            }
            $fws_[$key][$ii] = $valArray;
            if ($fwsDebug) {
                echo "Array post -> fws_['" . $key . "']['" . $ii . "'] => " . $valArray . " - " . $fws_[$key][$ii] . "<br>";
            }
        }
    }
}

If (@$fws_['msg'] == "") {
    $fws_['msg'] = $_GET['MSG'];
//    if (!mb_detect_encoding($fws_['msg'] . 'x', 'UTF-8, ISO-8859-1') == 'UTF-8') {
//        $fws_['msg'] = utf8_decode(addslashes($fws_['msg']));
//    } else {
        $fws_['msg'] = addslashes($fws_['msg']);
//    }
}

require_once(dirname(__FILE__)."/functions/functions.php");

define('COD_EVENTO',  '7');
define('WB_GRUPO', 'inesco');
define('WB_PROJETO', '6congresso');

$COD_EVENTO = COD_EVENTO;
$cod_evento = COD_EVENTO;

$PROTOCOLO = "https";
//if($_SERVER["HTTPS"]){
//    $PROTOCOLO = "https";
//}
switch ($_SERVER["SERVER_NAME"]) {

    case "localhost":
        $PROTOCOLO = "http";
        define('WB_PERSPECTIVA', 'local');
        define('WB_URL', 'http://localhost');
        define('WB_ROOT', $_SERVER['DOCUMENT_ROOT']."/" );
        //definindo WB_PROJETO
        $dir = dirname(__FILE__);
        $arrayDir = explode('\\', $dir);
//        define('WB_PROJETO', $arrayDir[count($arrayDir)-3]);
        @define('WB_PROJETO', '5congresso');
        @define('WB_PATH', '/'.WB_GRUPO.'/'.WB_PROJETO.'/inscricoes');
        include 'config-padrao.php';
        break;
    case "localhost:8080":
        $PROTOCOLO = "http";
        define('WB_PERSPECTIVA', 'local');
        define('WB_URL', 'http://localhost:8080');
        define('WB_ROOT', $_SERVER['DOCUMENT_ROOT'] );
        //definindo WB_PROJETO
        $dir = dirname(__FILE__);
        $arrayDir = explode('\\', $dir);
//        @define('WB_PROJETO', $arrayDir[count($arrayDir)-3]);
        @define('WB_PROJETO', '5congresso');
        @define('WB_PATH', '/'.WB_GRUPO.'/'.WB_PROJETO.'/inscricoes');
        include 'config-padrao.php';
        break;
    case "particular.localhost":
        $PROTOCOLO = "http";
        define('WB_PERSPECTIVA', 'local');
        define('WB_URL', 'http://particular.localhost');
        define('WB_ROOT', $_SERVER['DOCUMENT_ROOT'] );
        //definindo WB_PROJETO
        $dir = dirname(__FILE__);
        $arrayDir = explode('\\', $dir);
        define('WB_PROJETO', $arrayDir[count($arrayDir)-3]);
        define('WB_PATH', '/'.WB_GRUPO.'/'.WB_PROJETO.'/inscricoes');
        include 'config-padrao.php';
        break;
    case "www.opctec.net.br":
    case "opctec.net.br":
        define('WB_PERSPECTIVA', 'local');
        define('WB_URL', 'https://www.opctec.net.br');
        define('WB_ROOT', $_SERVER['DOCUMENT_ROOT'] ."/");
        //definindo WB_PROJETO
        $dir = dirname(__FILE__);
        //para linux a barra do explode para separar os diretório é ao contrario
        $arrayDir = explode('/', $dir);
//        define('WB_PROJETO', $arrayDir[count($arrayDir)-3]);
        define('WB_PATH', '/'.WB_GRUPO.'/'.WB_PROJETO.'/inscricoes');
        define('GOOGLE_KEY', '6Lc2oAIbAAAAABgnuDtnwj9twSFm1IXHKzN6Xi-K');

        define('URL_LOGO', WB_URL);
        define('URL_HOME_MENU', 'https://www.congressosaudepublica.org.br');
        define('URL_HALL', WB_URL.'/inesco/6congresso/digital_hall');
        define('URL_OFICIAL', WB_URL.'/inesco/6congresso/inscricoes/index.php?content=view/inscricao/inscricao_01.php#inscricao');
        include 'config-6congresso.php';
        break;
    case "www.opctec.com.br":
    case "opctec.com.br":
        define('WB_PERSPECTIVA', 'local');
        define('WB_URL', 'https://www.opctec.com.br');
        define('WB_ROOT', $_SERVER['DOCUMENT_ROOT'] ."/");
        //definindo WB_PROJETO
        $dir = dirname(__FILE__);
        //para linux a barra do explode para separar os diretório é ao contrario
        $arrayDir = explode('/', $dir);
//        define('WB_PROJETO', $arrayDir[count($arrayDir)-3]);
        define('WB_PATH', '/'.WB_GRUPO.'/'.WB_PROJETO.'/inscricoes');
        define('GOOGLE_KEY', '6LegLLkUAAAAAPmMa9BQnN6VSOKQ4xAwADvbHZM1');

        define('URL_LOGO', WB_URL);
        define('URL_HOME_MENU', 'https://www.congressosaudepublica.org.br');
        define('URL_HALL', WB_URL.'/inesco/6congresso/digital_hall');
        define('URL_OFICIAL', WB_URL.'/inesco/6congresso/inscricoes/index.php?content=view/inscricao/inscricao_01.php#inscricao');
        include 'config-6congresso.php';
        break;
    case "www.pagamento.associar.me":
    case "www.pagamento.associar-me.com.br":
    case "www.pagamento.associarme.com.br":
        define('WB_PERSPECTIVA', 'local');
        define('WB_URL', 'https://www.pagamento.associar-me.com.br');
        define('WB_ROOT', $_SERVER['DOCUMENT_ROOT'] ."/");
        //definindo WB_PROJETO
        $dir = dirname(__FILE__);
        //para linux a barra do explode para separar os diretório é ao contrario
        $arrayDir = explode('/', $dir);
//        define('WB_PROJETO', $arrayDir[count($arrayDir)-3]);
        define('WB_PATH', '/');
        define('GOOGLE_KEY', '6LegLLkUAAAAAPmMa9BQnN6VSOKQ4xAwADvbHZM1');

        define('URL_LOGO', WB_URL);
        define('URL_BOLETO', WB_URL);
        define('URL_HALL', WB_URL.'/digital_hall');
        define('URL_OFICIAL', 'https://www.inesco.associar-me.com.br');
        if($_GET['content']=='view/inscricao/inscricao_01.php'){
            header('Location: '.URL_OFICIAL);
            exit();
        }
        include 'config-associar-me.php';
        break;
    case "6ongresso.opctec.net.br":
        $PROTOCOLO = "https";
        define('WB_PERSPECTIVA', 'prod');
        define('WB_URL', 'https://6ongresso.opctec.net.br/inscricoes');
        define('WB_ROOT', $_SERVER['DOCUMENT_ROOT'] ."/");
        //definindo WB_PROJECT
        $dir = dirname(__FILE__);
        //para linux a barra do explode para separar os diretório é ao contrario
        $arrayDir = explode('/', $dir);
        define('WB_PROJECT', '7mostraparanaensesaude');
        define('WB_PATH', '/'.WB_GRUPO.'/'.WB_PROJETO.'/inscricoes');
        //define('GOOGLE_KEY', '6Lcv0GMaAAAAAJyq3wDctgoOVUXO1_pguz4H3kgU');
        include 'config-6congresso.php';
        break;
    case "6ongresso.opctec.com.br":
        $PROTOCOLO = "https";
        define('WB_PERSPECTIVA', 'prod');
        define('WB_URL', 'https://6ongresso.opctec.com.br/inscricoes');
        define('WB_ROOT', $_SERVER['DOCUMENT_ROOT'] ."/");
        //definindo WB_PROJECT
        $dir = dirname(__FILE__);
        //para linux a barra do explode para separar os diretório é ao contrario
        $arrayDir = explode('/', $dir);
        define('WB_PROJECT', '');
        define('WB_PATH', 'inscricoes');
        //define('GOOGLE_KEY', '6Lcv0GMaAAAAAJyq3wDctgoOVUXO1_pguz4H3kgU');
        include 'config-padrao.php';
        break;
    case "sis.congressosaudepublica.org.br":
        $PROTOCOLO = "http";
        define('WB_PERSPECTIVA', 'prod');
        define('WB_URL', 'http://sis.congressosaudepublica.org.br');
        define('WB_ROOT', $_SERVER['DOCUMENT_ROOT'] ."/");
        //definindo WB_PROJECT
        $dir = dirname(__FILE__);
        //para linux a barra do explode para separar os diretório é ao contrario
        $arrayDir = explode('/', $dir);
        define('WB_PROJECT', '6congresso');
        define('WB_PATH', '/'.WB_GRUPO.'/'.WB_PROJETO.'/inscricoes');
        define('GOOGLE_KEY', '6Lfv_esUAAAAAFR__aSkej8rLQBQf6aK4FTfar01');
        include 'config-padrao.php';
        break;
    case "eventos.test":
        $PROTOCOLO = "https";
        define('WB_PERSPECTIVA', 'local');
        define('WB_URL', 'https://eventos.test');
        define('WB_ROOT', $_SERVER['DOCUMENT_ROOT'].'/');
        define('WB_PATH', '/'.WB_GRUPO.'/'.WB_PROJETO.'/inscricoes');

        define('URL_LOGO', 'https://eventos.test');
        define('URL_BOLETO', 'https://eventos.test');
        define('URL_HALL', 'https://eventos.test/inesco/6congresso/digital_hall');
        define('URL_OFICIAL', 'https://eventos.test/inesco/6congresso/inscricoes/index.php?content=view/inscricao/inscricao_01.php#inscricao');
        include 'config-6congresso.php';
        break;
    default :
        define('WB_PERSPECTIVA', 'prod');
        define('WB_URL', 'http://www.opctec.com.br');
        define('WB_ROOT', $_SERVER['DOCUMENT_ROOT']);
        //definindo WB_PROJETO
        $dir = dirname(__FILE__);
        $arrayDir = explode('\\', $dir);
//        define('WB_PROJETO', $arrayDir[count($arrayDir)-3]);
        define('WB_PATH', '/'.WB_GRUPO.'/'.WB_PROJETO.'/inscricoes');
        include 'config-padrao.php';
        break;
}
